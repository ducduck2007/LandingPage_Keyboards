// <====== SCROLL MENU ======>
function targetTokenomics() {
    event.preventDefault();

    // Kiểm tra xem modal có đang mở hay không
    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
        $('.modal').on('hidden.bs.modal', function () {
            document.getElementById("tokenomics").scrollIntoView({
                behavior: "smooth",
            });
            $(this).off('hidden.bs.modal');
        });
    } else {
        document.getElementById("tokenomics").scrollIntoView({
            behavior: "smooth",
        });
    }
}


function targetRoadmap() {
    event.preventDefault();

    // Kiểm tra xem modal có đang mở hay không
    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
        $('.modal').on('hidden.bs.modal', function () {
            document.getElementById("roadmap").scrollIntoView({
                behavior: "smooth",
            });
            $(this).off('hidden.bs.modal');
        });
    } else {
        document.getElementById("roadmap").scrollIntoView({
            behavior: "smooth",
        });
    }
}

function targetMarketplace() {
    event.preventDefault();
    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
        $('.modal').on('hidden.bs.modal', function () {
            document.getElementById("marketplace").scrollIntoView({
                behavior: "smooth",
            });
            $(this).off('hidden.bs.modal');
        });
    } else {
        document.getElementById("marketplace").scrollIntoView({
            behavior: "smooth",
        });
    }
}

function targetAudit() {
    event.preventDefault();
    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
        $('.modal').on('hidden.bs.modal', function () {
            document.getElementById("audit").scrollIntoView({
                behavior: "smooth",
            });
            $(this).off('hidden.bs.modal');
        });
    } else {
        document.getElementById("audit").scrollIntoView({
            behavior: "smooth",
        });
    }
}

// <====== TO TOP ======>
document.addEventListener("DOMContentLoaded", () => {
    const scrollBtn = document.querySelector(".noneScroll");

    window.addEventListener("scroll", () => {
        if (
            document.body.scrollTop > 20 ||
            document.documentElement.scrollTop > 20
        ) {
            scrollBtn.style.display = "block";
        } else {
            scrollBtn.style.display = "none";
        }
    });

    scrollBtn.addEventListener("click", () => {
        window.scroll({
            top: 0,
            behavior: "smooth",
        });
    });
});


function closeModalsAndScrollToTop() {
    event.preventDefault();

    // Kiểm tra xem có modal nào đang mở không
    if ($('.modal.show').length > 0) {
        // Đóng tất cả các modal đang mở
        $('.modal.show').modal('hide');

        // Sau khi tất cả modal đóng, cuộn lên đầu trang
        $('.modal').on('hidden.bs.modal', function () {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            // Xóa sự kiện sau khi modal đã đóng và cuộn trang
            $(this).off('hidden.bs.modal');
        });
    } else {
        // Nếu không có modal mở, cuộn ngay lập tức lên đầu trang
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
}
