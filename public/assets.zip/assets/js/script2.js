if (sessionStorage.getItem(0)) {

    console.log(2123);
    if (window.socket == null) {
        window.socket = new WebSocket("wss://apptelemini.gamehay24h.vip:4368");
    }

    // Khi kết nối được mở
    window.socket.onopen = function (event) {
        console.log("Kết nối Websocket thành công!");
        document.getElementById("btnLogin").style.display = 'none';

        if (sessionStorage.getItem("walletAddress2")) {
            var dataSendFirst = {
                cmd: 0,
                data: {
                    type: 2,
                    telegramId: "",
                    walletAddress: sessionStorage.getItem("walletAddress2"),
                    version: "3",
                    language: "vi",
                    platform: "3",
                    device: "windows",
                    browser: "chrome",
                    network: sessionStorage.getItem("network"),
                    coin: sessionStorage.getItem("coin"),
                    token: sessionStorage.getItem("token")
                }
            };
        }
        else {
            var dataSendFirst = {
                cmd: 0,
                data: {
                    type: sessionStorage.getItem('1'),
                    telegramId: sessionStorage.getItem('2'),
                    walletAddress: "",
                    keyhash: sessionStorage.getItem('3'),
                    version: "3",
                    language: "vi",
                    platform: "3",
                    device: "windows",
                    browser: "chrome"
                }
            };
        }

        console.log(JSON.stringify(dataSendFirst));
        window.socket.send(JSON.stringify(dataSendFirst));
    };

    // Khi nhận được tin nhắn từ server
    window.socket.onmessage = function (event) {
        console.log("Dữ liệu nhận được từ server Eventdata:", event.data);
        eventData = JSON.parse(event.data);

        if (eventData.cmd == 2) {
            var displayName = eventData.data.displayName;

            document.getElementById("yourSKP").innerText = "YOUR SKP =" + Number(eventData.data.skpTransaction).toLocaleString('de-DE');
            document.getElementById("yourBullet").innerText = "YOUR BULLET =" + Number(eventData.data.bulletTransaction).toLocaleString('de-DE');

            sessionStorage.setItem("skpTransaction", eventData.data.skpTransaction);
            sessionStorage.setItem("bulletTransaction", eventData.data.bulletTransaction);

            console.log(`displayname: ${displayName}`);
            if (displayName.length > 20) {
                var displayNameShort = displayName.slice(0, 5) + "...." + displayName.slice(-5);
                document.getElementById('accountInfo').innerText = displayNameShort;
            } else {
                document.getElementById('accountInfo').innerText = displayName;
            }

            document.getElementById("btnLogin").style.display = 'none';
            document.getElementById("userData").style.display = 'block';

            sessionStorage.setItem("codeHash", eventData.data.codeHash);

            if (!sessionStorage.getItem("connectWallet")) {
                if (eventData.data.walletAddress == '') {
                    console.log(`không ví`);

                    console.log(eventData.data.walletAddress);
                    document.getElementById("connectWalletToGamemini1").style.display = 'block';
                    document.getElementById("connectWallet").style.display = 'none';
                    document.getElementById("connectWalletToGameMini3").style.display = 'block';
                } else {
                    console.log(`có ví`);
                    sessionStorage.setItem("walletAddress", eventData.data.walletAddress);
                    document.getElementById("connectWalletToGamemini1").style.display = 'none';

                    var windowWidth = window.screen.width;
                    console.log(windowWidth);
                    if (windowWidth > 800) {
                        connectMetamask();
                    }else{
                        connectWalletConnect();
                    }
                }
            } else {
                document.getElementById("connectWalletToGamemini1").style.display = 'none';
            }

            // phần lưu dữ liệu sang bảng info
            if (eventData.data.displayName.length > 20) {
                document.getElementById("nameAccountDetail").textContent = eventData.data.displayName.slice(0, 5) + "...." + eventData.data.displayName.slice(-5);
            } else {
                document.getElementById("nameAccountDetail").textContent = eventData.data.displayName;
            }
            document.getElementById("walletAddressDetail").textContent = eventData.data.walletAddress.slice(0, 5) + "...." + eventData.data.walletAddress.slice(-5);
            document.getElementById("numberSKPDetail").textContent = eventData.data.skp;
            document.getElementById("yourSKP").textContent = "YOUR SKP = " + eventData.data.skp;

            document.getElementById("numberSKCDetail").textContent = eventData.data.skc;
            document.getElementById("numberBulletDetail").textContent = eventData.data.bullet;
            document.getElementById("yourBullet").textContent = "YOUR BULLET = " + eventData.data.bullet;


            if(!localStorage.setItem("bullet") || !localStorage.setItem("skp") || !localStorage.setItem("sellBullet") || !localStorage.setItem("sellSKP") || !localStorage.setItem("sellUSDT")){
                var infoBuyBullet = {
                    cmd: 100,
                    data: {}
                };

                var infoBuySKP = {
                    cmd: 101,
                    data: {}
                };

                var infoSellBullet = {
                    cmd: 102,
                    data: {}
                };

                var infoSellSKP = {
                    cmd: 103,
                    data: {}
                };

                var infoSellUSDT = {
                    cmd: 104,
                    data: {}
                };

                window.socket.send(JSON.stringify(infoBuyBullet));
                window.socket.send(JSON.stringify(infoBuySKP));
                window.socket.send(JSON.stringify(infoSellBullet));
                window.socket.send(JSON.stringify(infoSellSKP));
                window.socket.send(JSON.stringify(infoSellUSDT));
            }

            document.getElementById("loadingSpinnerHome").style.display = "none";

        }

        if (eventData.cmd == 6) {
            var versionCmd100 = eventData.data.versionCmd100;
            var versionCmd101 = eventData.data.versionCmd101;
            var versionCmd102 = eventData.data.versionCmd102;
            var versionCmd103 = eventData.data.versionCmd103;
            var versionCmd104 = eventData.data.versionCmd104;
            var versionCmd105 = eventData.data.versionCmd105;
            var versionCmd106 = eventData.data.versionCmd106;

            if(!localStorage.getItem("versionCmd100") || localStorage.getItem("versionCmd100") != versionCmd100){
                var infoBuyBullet = {
                    cmd: 100,
                    data: {}
                };
                window.socket.send(JSON.stringify(infoBuyBullet));
            }

            if(!localStorage.getItem("versionCmd101") || localStorage.getItem("versionCmd101") != versionCmd101){
                var infoBuySKP = {
                    cmd: 101,
                    data: {}
                };
                window.socket.send(JSON.stringify(infoBuySKP));
            }

            if(!localStorage.getItem("versionCmd102") || localStorage.getItem("versionCmd102") != versionCmd102){
                var infoSellBullet = {
                    cmd: 102,
                    data: {}
                };
                window.socket.send(JSON.stringify(infoSellBullet));
            }

            if(!localStorage.getItem("versionCmd103") || localStorage.getItem("versionCmd103") != versionCmd103){
                var infoSellSKP = {
                    cmd: 103,
                    data: {}
                };
                window.socket.send(JSON.stringify(infoSellSKP));
            }

            if(!localStorage.getItem("versionCmd104") || localStorage.getItem("versionCmd104") != versionCmd104){
                var infoSellUSDT = {
                    cmd: 104,
                    data: {}
                };
                window.socket.send(JSON.stringify(infoSellUSDT));
            }

            localStorage.setItem("versionCmd101") = versionCmd101;
            localStorage.setItem("versionCmd102") = versionCmd102;
            localStorage.setItem("versionCmd103") = versionCmd103;
            localStorage.setItem("versionCmd104") = versionCmd104;
            localStorage.setItem("versionCmd105") = versionCmd105;
            localStorage.setItem("versionCmd106") = versionCmd106;

        }

        //ẩn nút kết nối sau khi kết nối xong
        if (eventData.cmd == 22) {
            if (eventData.data.result == 1) {
                document.getElementById("connectWalletToGamemini1").style.display = 'none';
                document.getElementById("connectWalletToGameMini3").style.display = 'none';

            }

            var myModal = new bootstrap.Modal(document.getElementById('connectGameMiniSuccess'), {
                keyboard: false
            });
            myModal.show();


        }

        if (eventData.cmd == 23) {
            $("#loadingSpinner").hide();

            var buySuccessModal = new bootstrap.Modal(document.getElementById('buySuccessWithCoin'));
            buySuccessModal.show();
        }

        if(eventData.cmd == 50){
            sessionStorage.setItem("listRank", JSON.stringify(eventData.data.bxh));

            if (sessionStorage.getItem("listRank")) {
                var listRank = JSON.parse(sessionStorage.getItem("listRank"));
                $('#tableListRank').empty();
 
                listRank.forEach(element => {
                    if (element.rank < 4) {
                        $('#tableListRank').append(
                            `<tr>
                             <th class="p-3 border_radius_left"
                                 style="background: #fffce4; line-height: 50px">
                                 <img src="{{ asset('assets/css/images/rank${element.rank}.png') }}" height="40px" />
                             </th>
                             <td class="p-3 d-flex align-items-center justify-content-center gap-3"
                                 style="background: #fffce4">
                                 <img class="col-2" src="https://placehold.co/50" style="width: 50px" alt="image" />
                                 <div class="col-10 name fw-semibold fs-5">${element.name}</div>
                             </td>
                             <td class="p-3 fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                                 ${Number(element.point).toLocaleString('de-DE')}
                             </td>
                             <td class="p-3 border_radius_right" style="background: #fffce4">
                                 <img src="{{ asset('assets/css/images/ruongDo${element.rank}.png') }}" height="50px" />
                             </td>
                         </tr>`
                        );
                    } else {
                        $('#tableListRank').append(
                            `<tr>
                             <th class="p-3 border_radius_left"
                                 style="background: #fffce4; line-height: 50px">
                                 ${element.rank}
                             </th>
                             <td class="p-3 d-flex align-items-center justify-content-center gap-3"
                                 style="background: #fffce4">
                                <img class="col-2" src="https://placehold.co/50" style="width: 50px" alt="image" />
                                 <div class="col-10 name fw-semibold fs-5">${element.name}</div>
                             </td>
                             <td class="p-3 fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                                 ${Number(element.point).toLocaleString('de-DE')}
                             </td>
                             <td class="p-3 border_radius_right" style="background: #fffce4">
                                 <img src="{{ asset('assets/css/images/gift.png') }}" height="50px" />
                             </td>
                         </tr>`
                        );
                    }
                });
            }
        }

        if(eventData.cmd == 51){
            console.log(eventData.data.history);
            sessionStorage.setItem("historyTrans", JSON.stringify(eventData.data.history));
            if (sessionStorage.getItem("historyTrans")) {
                console.log(`ddoor duwx lieuej`);
                var historyTrans = JSON.parse(sessionStorage.getItem("historyTrans"));
                $('#tableHistoryTrans').empty();
 
                historyTrans.forEach(element => {
                    var checkStatus = "";
                    if (element.status == 1) {
                        checkStatus = "Success";
                    } else if (element.status == 0) {
                        checkStatus = "Wait";
                    }
 
                    var typeOrder = "";
                    var typePay = "";
                    if (element.typeTran == 1) {
                        typeOrder = "Bullet";
                        typePay = "BNB";
                    } else if (element.typeTran == 2) {
                        typeOrder = "Token SKP";
                        typePay = "BNB";
                    } else if (element.typeTran == 4) {
                        typeOrder = "Bullet";
                        typePay = "Coin";
                    } else if (element.typeTran == 5) {
                        typeOrder = "Token SKP";
                        typePay = "Coin";
                    } else if (element.typeTran == 6) {
                        typeOrder = "USDT";
                        typePay = "Coin";
                    }
 
                    $('#tableHistoryTrans').append(
                        `<tr class="p-3">
                  <th class="border_radius_left" style="background: #fffce4; line-height: 50px">
                      1
                  </th>
                  <td class="fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                      Mua ${typeOrder} bằng ${typePay}
                  </td>
                  <td class="fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                      ${element.order} ${typeOrder}
                  </td>
                  <td class="fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                      ${element.payment} ${typePay}
                  </td>
                  <td class="fw-semibold fs-5" style="background: #fffce4; line-height: 50px">
                      ${element.timeCreate}
                  </td>
                  <td class="text-success fw-semibold fs-5 border_radius_right"
                      style="background: #fffce4; line-height: 50px">
                      ${checkStatus}
                  </td>
              </tr>`
                    );
                })
            }
        }

        if(eventData.cmd == 80){
            document.getElementById("numberSKCDetail").innerText = eventData.data.skc;
        }
        if(eventData.cmd == 81){
            document.getElementById("numberSKPDetail").innerText = eventData.data.skp;     
        }
        if(eventData.cmd == 82){
            document.getElementById("numberBulletDetail").innerText = eventData.data.bullet;            
        }
        if(eventData.cmd == 83){
            if(eventData.data.skpTransaction){
                var skpTrans2 = sessionStorage.getItem("skpTransaction") + eventData.data.skpTransaction;
                sessionStorage.setItem("skpTransaction", skpTrans2);
                document.getElementById("yourSKP").innerText = "YOUR SKP =" + Number(skpTrans2).toLocaleString('de-DE');
            }

            if(eventData.data.bulletTransacton){
                var bulletTrans2 = sessionStorage.getItem("bulletTransacton") + eventData.data.bulletTransacton;
                sessionStorage.setItem("bulletTransacton", bulletTrans2);
                document.getElementById("yourBullet").innerText = "YOUR BULLET =" + Number(bulletTrans2).toLocaleString('de-DE');
            }
        }

        //phần lấy dữ liệu 2 cái mua ở index của web
        if (eventData.cmd == 100) {
            var arrayInfo = eventData.data.info;
            // if(!localStorage.getItem("bullet")){
            //     var lstBullet = JSON.stringify(arrayInfo);

            //     console.log(`lstBullet2: ${lstBullet}`);
            //     JSON.parse(lstBullet).forEach(element => {                    
            //         $('#listButtonBuy').append(
            //             `<button class="col-sm-2 btn btn-custom-darkGreen fw-bold text-center p-1" data-bnb="${element.bnb.toFixed(18)}"
            //                 data-type="${element.type}" data-bullet="${element.bullet}" onclick="updateBNBAmount(this)">${element.bullet}</button>`
            //         );
            //     });
            // }
            localStorage.setItem('bullet', JSON.stringify(arrayInfo));
        }

        if (eventData.cmd == 101) {
            var arrayInfo = eventData.data.info;
            if (!localStorage.getItem("skp")) {
                var lstSKP = JSON.stringify(arrayInfo);

                console.log(`lstSKP2: ${lstSKP}`);
                JSON.parse(lstSKP).forEach(element => {
                    $('#listButtonBuy').append(
                        `<button class="col-sm-2 btn btn-custom-darkGreen fw-bold text-center p-1" data-bnb="${element.bnb.toFixed(18).replace(/\.?0+$/, '')}"
                            data-type="${element.type}" data-skp="${element.skp}" onclick="updateBNBAmount(this)">${element.skp}</button>`
                    );
                });
            }
            localStorage.setItem('skp', JSON.stringify(arrayInfo));
        }

        if (eventData.cmd == 102) {
            console.log(`sell bullet: ${event.data}`);
            var arrayInfo = eventData.data.info;
            localStorage.setItem('sellBullet', JSON.stringify(arrayInfo));
        }

        if (eventData.cmd == 103) {
            console.log(`sell token: ${event.data}`);
            var arrayInfo = eventData.data.info;
            localStorage.setItem('sellSKP', JSON.stringify(arrayInfo));
        }

        if (eventData.cmd == 104) {
            var arrayInfo = eventData.data.info;
            localStorage.setItem('sellUSDT', JSON.stringify(arrayInfo));
            console.log(`sell usdt: ${event.data}`);
        }


        if (eventData.cmd == 120) {
            console.log(`chayj vào hàm update trans`);
            var idCheck = eventData.data.history.id;
            if(sessionStorage.getItem("historyTrans")){
                var historyTrans = JSON.parse(sessionStorage.getItem("historyTrans"));
                var is = false;
                historyTrans.forEach((element, index) => {
                    if (element.id == idCheck) {
                        // Thay thế phần tử hiện tại bằng dữ liệu eventData.data.history
                        historyTrans[index] = eventData.data.history;
                        is = true;
                    }
                });

                if (!is) {
                    historyTrans.push(eventData.data.history);
                }

                sessionStorage.setItem("historyTrans", JSON.stringify(historyTrans));

                loadHistoryTransaction();
            }
        }

        if (eventData.cmd == 121) {
            sessionStorage.setItem("walletAddress", eventData.data.walletAddress);
            sessionStorage.setItem("walletAddress2", eventData.data.walletAddress);
            sessionStorage.setItem("codeHash", eventData.data.codeHash);

            document.getElementById("accountInfo").innerText = eventData.data.displayName;
            document.getElementById("nameAccountDetail").innerText = eventData.data.displayName;
            eventData.data.walletAddress.slice(0, 5) + "...." + eventData.data.walletAddress.slice(-5)
            document.getElementById("walletAddressDetail").innerText = eventData.data.walletAddress.slice(0, 5) + "...." + eventData.data.walletAddress.slice(-5);

            document.getElementById("numberSKCDetail").innerText = eventData.data.skc;
            document.getElementById("numberSKPDetail").innerText = eventData.data.skp;     
            document.getElementById("numberBulletDetail").innerText = eventData.data.bullet;   
        }

        if (eventData.cmd == 200) {
            window.socket.close();
            console.log("WebSocket connection closed.");
              
            // Xóa các thông tin đăng nhập trong sessionStorage
            sessionStorage.clear()
            document.getElementById("userData").style.setProperty("display", "none", "important");

            // Cập nhật giao diện
            document.getElementById("btnLogin").style.display = "block";

            document.getElementById("userData").style.setProperty("display", "none", "important");

            document.getElementById("connectWallet").style.display = "block";
            document.getElementById("accountInfo").classList.add("hidden");
        
            document.getElementById("sendBNB").style.display = "none";
            document.getElementById("sendBNBMobile").style.display = "none";

            console.log("User logged out.");
            document.getElementById("loadingSpinnerHome").style.display = "none";

        }
        if (eventData.cmd == 0) {
            if(eventData.data.result == 0){
                window.socket.close();
                alert("Data server not found!!!");

                console.log("WebSocket connection closed.");
                  
                // Xóa các thông tin đăng nhập trong sessionStorage
                sessionStorage.clear()
                document.getElementById("userData").style.setProperty("display", "none", "important");
    
                // Cập nhật giao diện
                document.getElementById("btnLogin").style.display = "block";
    
                document.getElementById("userData").style.setProperty("display", "none", "important");
    
                document.getElementById("connectWallet").style.display = "block";
                document.getElementById("accountInfo").classList.add("hidden");
            
                document.getElementById("sendBNB").style.display = "none";
                document.getElementById("sendBNBMobile").style.display = "none";
                document.getElementById("loadingSpinnerHome").style.display = "none";


            }
        }
    };

    window.socket.onclose = function (event) {
        if (event.wasClean) {
            console.log(`Đóng kết nối ws, mã: ${event.code}, lý do: ${event.reason}`);
        } else {
            console.log(`Kết nối bị ngắt đột ngột`);
        }
        sessionStorage.clear()
        document.getElementById("btnLogin").style.display = "block";
        document.getElementById("userData").style.display = "none";
        document.getElementById("connectWallet").style.display = "block";

        document.getElementById("userData").style.setProperty("display", "none", "important");

        document.getElementById("sendBNB").style.display = "none";
        document.getElementById("sendBNBMobile").style.display = "none";
        document.getElementById("loadingSpinnerHome").style.display = "none";



        // Thử reconnect sau 5 giây
        // setTimeout(() => {
        //     window.socket = new WebSocket("wss://apptelemini.gamehay24h.vip:4368");
        // }, 5000);
    };

    window.socket.onerror = function (error) {
        console.log(`Lỗi WebSocket:`, error);

        sessionStorage.clear()
        document.getElementById("btnLogin").style.display = "block";
        document.getElementById("userData").style.display = "none";
        document.getElementById("connectWallet").style.display = "block";

        document.getElementById("userData").style.setProperty("display", "none", "important");

        document.getElementById("sendBNB").style.display = "none";
        document.getElementById("sendBNBMobile").style.display = "none";
        document.getElementById("loadingSpinnerHome").style.display = "none";



    };
}
// else{
//     alert("No data!!!");
// }

