<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Faq;
use Carbon\Carbon;
use DB;

class FaqController extends Controller
{
    public function index(Request $request)
    {

        $data = DB::table('faqs')->orderBy('vi_tri')->get()->keyBy('vi_tri')->toArray();
        return view('admin.faq.faq_index', compact('data'));
    }
    public function create(Request $request)
    {
      return view('admin.faq.faq_create');
    }
    public function postCreate(Request $req)
    {
      $model = new Faq;
      $model->fill($req->all());
      // $model->slug = Str::slug($req->title, '-');
  
      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }
  
  
      if ($model->save()) {
        return redirect()->route('faq.index')->withErrors('Tạo freature thành công!');
      }
    }
    public function update($id)
    {
      $model = Faq::find($id);
      if($model){
        return view('admin.faq.faq_update', compact('model'));
      }
    }
    public function postUpdate(Request $req)
    {
      $model = Faq::find((int)$req->id);
  
      if (!$model)
        return redirect()->route('faq.index')->withErrors('Không tìm thấy sự kiện!');
      else {
        $model->fill($req->all());
        // $model->slug = Str::slug($req->title, '-');
  
        if ($model->save()) {
          return redirect()->route('faq.index')->withErrors('Update feature thành công!');
        }
      }
    }
  
    public function delete(Request $req)
    {
      if ($req->ajax()) {
  
        try {
          $pr = Feature::find((int)$req->id);
  
          if ($pr->delete()) {
  
            return response(['message' => 'success']);
          } else {
  
            return response(['message' => 'fail']);
          }
        } catch (\Exception $e) {
        }
      }
    }
}
