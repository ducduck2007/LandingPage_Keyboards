<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Nft;
use App\Game;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Admin\FunctionController;
use App\Http\Requests\NftRequest;
use DB;
use Illuminate\Support\Str;
use App\Tag;
use App\TagList;
use App\Http\Requests\NewsRequest;
use App\Http\Requests\NewsUpdateRequest;

class NftController extends Controller
{
  public function index(Request $request)
  {

    $data = DB::select("SELECT * FROM nft");
    return view('admin.nft.nft_index', compact('data'));
  }
  public function create(Request $request)
  {
    return view('admin.nft.nft_create');
  }
  public function postCreate(NftRequest $req)
  {
    $model = new Nft;
    $model->fill($req->all());
    // $model->slug = Str::slug($req->title, '-');
  
    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
    }
  
    if ($req->hasFile('icon')) {
      $file = $req->file('icon');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->icon = 'uploads/' . $fileName;
    }
  
    $model->save();
    return Redirect::back()->withErrors('Tạo NFT thành công!')->withInput();
    
  }

  public function update($id)
  {
    $model = Nft::find($id);
    if($model){
      return view('admin.nft.nft_update', compact('model'));
    }
  }
  public function postUpdate(NewsUpdateRequest $req)
  {
    $model = Nft::find((int)$req->id);

    if (!$model)
      return Redirect::back()->withErrors('Không tìm thấy sự kiện!');
    else {
      $model->fill($req->all());
      $model->slug = Str::slug($req->title, '-');

      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }

      if ($req->hasFile('icon')) {
        $file = $req->file('icon');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->icon = 'uploads/' . $fileName;
      }

      if ($model->save()) {
        return Redirect::back()->withErrors('Upload NFT thành công!')->withInput();        
      }
    }
  }

  public function delete(Request $req)
  {
    if ($req->ajax()) {

      try {
        $pr = Nft::find((int)$req->id);

        if ($pr->delete()) {

          return response(['message' => 'success']);
        } else {

          return response(['message' => 'fail']);
        }
      } catch (\Exception $e) {
      }
    }
  }
}
