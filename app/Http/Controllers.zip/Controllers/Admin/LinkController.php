<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Link;

class LinkController extends Controller
{
    public function index(Request $request)
    {
        $data=Link::all();
    
        return view('admin.link_copy.link_copy_index',compact('data'));
    }
    public function create(Request $request)
    {
       
        return view('admin.link_copy.link_copy_create');
    }
    public function postCreate(Request $req)
    {
        $model =new Link;
        
        $model->fill($req->all());
        if ($req->hasFile('icon')) {
            $file = $req->file('icon');
            $fileName = uniqid() . "-" . $file->getClientOriginalName();
            $file->storeAs('uploads', $fileName);
            $model->icon = 'uploads/' . $fileName;
            
        }
        if($model->save()){
        return Redirect::back()->withErrors('Tạo slider thành công!' )->withInput(); 
        }
        
    }
    public function update($id)
    {
   
        try{  
            $model = Link::find($id);
        // $model->fill($req->all());
            if (!$model) {
            return Redirect::back()->withErrors('Không tìm thấy user!' );
            }
            return view('admin.link_copy.link_copy_update', compact('model'));
        }catch (\Exception $e) {
            
        }
        
    }
    public function postUpdate(Request $req)
    {
        $model = Link::find((int)$req->id);
            
        if(!$model)
            return Redirect::back()->withErrors('Không tìm thấy !' );
        else{
            
            $model->fill($req->all());
            if ($req->hasFile('icon')) {
                $file = $req->file('icon');
                $fileName = uniqid() . "-" . $file->getClientOriginalName();
                $file->storeAs('uploads', $fileName);
                $model->icon = 'uploads/' . $fileName;
                
            }
            if($model->save()){
                return Redirect::back()->withErrors('Upload thành công!' )->withInput(); 
            }
        }
    }
    public function delete(Request $req)
    {
        if($req->ajax()){
        
            try{
                $pr = Link::find((int)$req->id);
            
                if($pr->delete()){
            
                    return response(['message'=>'success']);
                }else{
                
                    return response(['message'=>'fail']);
                }
            }catch (\Exception $e) {
                
            
            }
        }
    }
}
