<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Footer;
use Carbon\Carbon;
use DB;

class FooterController extends Controller
{
    public function index(Request $request)
    {
      $data = DB::select("SELECT * FROM footer");
  
      return view('admin.footer.footer_index', compact('data'));
    }
    public function create(Request $request)
    {
      return view('admin.footer.footer_create');
    }
    public function postCreate(Request $req)
    {
      $model = new Footer;
      $model->fill($req->all());
      if ($req->hasFile('icon')) {
        $file = $req->file('icon');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->icon = 'uploads/' . $fileName;
      }
  
      if ($model->save()) {
        return redirect()->route('footer.index')->withErrors('Thêm video thành công!')->withInput();
      }
    }
    public function update($id)
    {
      $model = Footer::find($id);
      if($model){
        return view('admin.footer.footer_update', compact('model'));
      }
    }
    public function postUpdate(Request $req)
    {
      $model = Footer::find((int)$req->id);
  
      if (!$model)
        return redirect()->route('footer.index')->withErrors('Không tìm thấy sự kiện!');
      else {
        $model->fill($req->all());
    
        if ($model->save()) {
          return redirect()->route('footer.index')->withErrors('Cập nhật thành công!')->withInput();
        }
      }
    }
  
    public function delete(Request $req)
    {
        if ($req->ajax()) {
            try {
                // Tìm đối tượng theo ID
                $pr = Footer::find((int)$req->id);
    
                if (!$pr) {
                    // Trả về lỗi nếu không tìm thấy đối tượng
                    return response(['message' => 'not_found'], 404);
                }
    
                if ($pr->delete()) {
                    return response(['message' => 'success']);
                } else {
                    return response(['message' => 'fail'], 500);
                }
            } catch (\Exception $e) {
                // Trả về thông tin lỗi chi tiết hơn
                return response(['message' => 'error', 'error' => $e->getMessage()], 500);
            }
        }
    }
    
  }
