<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Investor;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\InvestorRequest;

class InvestorController extends Controller
{
    public function index(Request $request)
  {
    $data=Investor::all();
    return view('admin.investor.investor_index',compact('data'));
  }
  public function create(Request $request)
  {
    
    return view('admin.investor.investor_create');
  }
  public function postCreate(InvestorRequest $req)
  {
    $model =new Investor;
    $model->fill($req->all());
   
    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
      
    }
    
    
    if($model->save()){
      return Redirect::back()->withErrors('Tạo tin tức thành công!' )->withInput(); 
    }
    
  }
  public function update($id)
  {
   
  
    try{  
      $model =Investor::find($id);
      // $model->fill($req->all());
        if (!$model) {
          return Redirect::back()->withErrors('Không tìm thấy tin tức!' );
        }
        return view('admin.investor.investor_update', compact('model'));
    }catch (\Exception $e) {
        
    }
    
  }
  public function postUpdate(Request $req)
  {
    $model = Investor::find((int)$req->id);
        
    if(!$model)
        return Redirect::back()->withErrors('Không tìm thấy tin tức!' );
    else{
        $model->fill($req->all());
        
      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
        
      }
      
      
      if($model->save()){
        return Redirect::back()->withErrors('Upload events thành công!' )->withInput(); 
      }
    }
  }
  public function delete(Request $req)
  {
    if($req->ajax()){
      
      try{
        $pr = Investor::find((int)$req->id);
      
        if($pr->delete()){
    
          return response(['message'=>'success']);
        }else{
          
          return response(['message'=>'fail']);
        }
      }catch (\Exception $e) {
          
          
      }
    }
  }
}
