<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Gameplay;
use App\Game;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Admin\FunctionController;
use App\Http\Requests\GameplayRequest;
use DB;
use Illuminate\Support\Str;
use App\Tag;
use App\TagList;
use App\Http\Requests\NewsRequest;
use App\Http\Requests\NewsUpdateRequest;

class GameplayController extends Controller
{
  public function index(Request $request)
  {
    $data=DB::select("SELECT * FROM gameplay"); 

    return view('admin.gameplay.gameplay_index', compact('data'));
  }
  public function create(Request $request)
  {
    return view('admin.gameplay.gameplay_create');
  }
  public function postCreate(GameplayRequest $req)
  {
    $model = new Gameplay;
    $model->fill($req->all());
    // $model->slug = Str::slug($req->title, '-');
  
    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
    }

    if ($model->save()) {
      // if ($req->has('tags')) {
      //   $arrName = [];
      //   // dd($arrCode);
      //   foreach ($req->tags as $g) {
      //     $arrName[] = [
      //       'id_tag' => $g,
      //       'id_join_table' => $model->id,
      //       'type' => 3,
      //     ];
      //     // array_push($arrCode,$gg);
      //   }
      //   if (!empty($arrName)) {
      //     $create = TagList::insert(
      //       $arrName
      //     );
      //   }
      // }
      return Redirect::back()->withErrors('Tạo gameplay thành công!')->withInput();
    }
  }
  
  public function update($id)
  {
    $model = Gameplay::find($id);
    return view('admin.gameplay.gameplay_update', compact('model'));

  }
  public function postUpdate(NewsUpdateRequest $req)
  {
    $model = Gameplay::find((int)$req->id);

    if (!$model)
      return Redirect::back()->withErrors('Không tìm thấy sự gameplay!');
    else {
      $model->fill($req->all());
      // $model->slug = Str::slug($req->title, '-');

      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }


      if($model->save()){
        return Redirect::back()->withErrors('Upload gameplay thành công!')->withInput();
      }
    }
  }

  public function delete(Request $req)
  {
    if ($req->ajax()) {

      try {
        $pr = Gameplay::find((int)$req->id);

        if ($pr->delete()) {

          return response(['message' => 'success']);
        } else {

          return response(['message' => 'fail']);
        }
      } catch (\Exception $e) {
      }
    }
  }

  public function deleteMultiple(Request $request)
  {
    $ids = $request->input('ids');
    if (!empty($ids)) {
        // Xóa các bản ghi có ID trong danh sách
        Gameplay::whereIn('id', $ids)->delete();

        return response()->json(['message' => 'success']);
    } else {
        return response()->json(['message' => 'error']);
    }
  }

}
