<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\TabLeft;
use Illuminate\Support\Facades\Redirect;
class TabLeftController extends Controller
{
    public function index(Request $request)
  {
    $data=TabLeft::all();
    return view('admin.tab_left.tab_left_index',compact('data'));
  }
  public function create(Request $request)
  {
    
    return view('admin.tab_left.tab_left_create');
  }
  public function postCreate(Request $req)
  {
    $model =new TabLeft;
    $model->fill($req->all());
   
    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
    }
    
    if($model->save()){
      return redirect()->route('tab_left.index')->withErrors('Create thành công!' )->withInput(); 
    }
    
  }
  public function update($id)
  {
    try{  
      $model =TabLeft::find($id);
      // $model->fill($req->all());
        if (!$model) {
          return redirect()->route('tab_left.index')->withErrors('Không tìm thấy tin tức!' );
        }
        return view('admin.tab_left.tab_left_update', compact('model'));
    }catch (\Exception $e) {
        
    }
    
  }

  public function postUpdate(Request $req)
  {
    $model = TabLeft::find((int)$req->id);
        
    if(!$model)
        return redirect()->route('tab_left.index')->withErrors('Không tìm thấy tin tức!' );
    else{
        $model->fill($req->all());
        
      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
        
      }
      
      
      if($model->save()){
        return redirect()->route('tab_left.index')->withErrors('Update thành công!' )->withInput(); 
      }
    }
  }

  public function delete(Request $req)
  {
    if($req->ajax()){
      
      try{
        $pr = TabLeft::find((int)$req->id);
      
        if($pr->delete()){
    
          return response(['message'=>'success']);
        }else{
          
          return response(['message'=>'fail']);
        }
      }catch (\Exception $e) {
          
          
      }
    }
  }
  public function deleteAll(Request $request)
  {
      try {
          TabLeft::query()->delete(); // Xóa tất cả các bản ghi từ model TabLeft
          return response()->json(['message' => 'success']);
      } catch (\Exception $e) {
          return response()->json(['message' => 'error']);
      }
  }  

}
