<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Slide;
use DB;

class SlideQuestionController extends Controller
{
    public function index(Request $request)
    {

        $data = DB::select("SELECT * FROM slide ORDER BY vi_tri");
        return view('admin.slide_question.slide_question_index', compact('data'));
    }
    public function create(Request $request)
    {
      return view('admin.slide_question.slide_question_create');
    }
    public function postCreate(Request $req)
    {
      $model = new Slide;
      $model->fill($req->all());
      // $model->slug = Str::slug($req->title, '-');
  
      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }
  
  
      if ($model->save()) {
        return redirect()->route('slideQuestion.index')->withErrors('Tạo freature thành công!');
      }
    }
    public function update($id)
    {
      $model = Slide::find($id);
      if($model){
        return view('admin.slide_question.slide_question_update', compact('model'));
      }
    }
    public function postUpdate(Request $req)
    {
      $model = Slide::find((int)$req->id);
  
      if (!$model)
        return redirect()->route('slideQuestion.index')->withErrors('Không tìm thấy sự kiện!');
      else {
        $model->fill($req->all());
        // $model->slug = Str::slug($req->title, '-');
  
        if ($model->save()) {
          return redirect()->route('slideQuestion.index')->withErrors('Update feature thành công!');
        }
      }
    }
  
    public function delete(Request $req)
    {
      if ($req->ajax()) {
  
        try {
          $pr = Slide::find((int)$req->id);
  
          if ($pr->delete()) {
  
            return response(['message' => 'success']);
          } else {
  
            return response(['message' => 'fail']);
          }
        } catch (\Exception $e) {
        }
      }
    }
}
