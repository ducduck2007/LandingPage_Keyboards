<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Feature;
use App\Game;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Admin\FunctionController;
use App\Http\Requests\EventRequest;
use DB;
use Illuminate\Support\Str;
use App\Http\Requests\NewsRequest;
use App\Http\Requests\NewsUpdateRequest;

class FeatureController extends Controller
{
  public function index(Request $request)
  {
    $data = DB::select("SELECT * FROM feature");

    return view('admin.feature.feature_index', compact('data'));
  }
  public function create(Request $request)
  {
    return view('admin.feature.feature_create');
  }
  public function postCreate(Request $req)
  {
    $model = new Feature;
    $model->fill($req->all());
    if ($req->hasFile('icon')) {
      $file = $req->file('icon');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->icon = 'uploads/' . $fileName;
    }

    if ($model->save()) {
      return redirect()->route('feature.index')->withErrors('Tạo freature thành công!')->withInput();
    }
  }
  public function update($id)
  {
    $model = Feature::find($id);
    if($model){
      return view('admin.feature.feature_update', compact('model'));
    }
  }
  public function postUpdate(NewsUpdateRequest $req)
  {
    $model = Feature::find((int)$req->id);

    if (!$model)
      return redirect()->route('feature.index')->withErrors('Không tìm thấy sự kiện!');
    else {
      $model->fill($req->all());
      // $model->slug = Str::slug($req->title, '-');
      
      if ($req->hasFile('icon')) {
        $file = $req->file('icon');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->icon = 'uploads/' . $fileName;
      }

      if ($model->save()) {
        return redirect()->route('feature.index')->withErrors('Update feature thành công!')->withInput();
      }
    }
  }

  public function delete(Request $req)
  {
    if ($req->ajax()) {

      try {
        $pr = Feature::find((int)$req->id);

        if ($pr->delete()) {

          return response(['message' => 'success']);
        } else {

          return response(['message' => 'fail']);
        }
      } catch (\Exception $e) {
      }
    }
  }
}
