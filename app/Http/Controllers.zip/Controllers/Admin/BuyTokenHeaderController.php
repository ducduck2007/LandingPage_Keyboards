<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\BuyTokenHeader;
use App\Game;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Admin\FunctionController;
use DB;
use Illuminate\Support\Str;
use App\Tag;
use App\TagList;
use App\Http\Requests\BuyTokenHeaderRequest;

class BuyTokenHeaderController extends Controller
{
  public function index(Request $request)
  {

    $data = DB::select("SELECT * FROM info_buy_with_bnb");
    return view('admin.buyTokenHeader.buyTokenHeader_index', compact('data'));
  }
  public function create(Request $request)
  {
    return view('admin.buyTokenHeader.buyTokenHeader_create');
  }
  public function postCreate(BuyTokenHeaderRequest $req)
  {
    $model = new BuyTokenHeader;
    $model->fill($req->all());
  
    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
    }

    if ($req->hasFile('image_not_selected')) {
      $file = $req->file('image_not_selected');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image_not_selected = 'uploads/' . $fileName;
    }
  
    $model->save();
    return Redirect::back()->withErrors('Tạo thành công!')->withInput();
    
  }

  public function update($id)
  {
    $model = BuyTokenHeader::find($id);
    if($model){
      return view('admin.buyTokenHeader.buyTokenHeader_update', compact('model'));
    }
  }
  public function postUpdate(Request $req)
  {
    $model = BuyTokenHeader::find((int)$req->id);

    if (!$model)
      return Redirect::back()->withErrors('Không tìm thấy sự kiện!');
    else {
      $model->fill($req->all());

      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }

      if ($req->hasFile('image_not_selected')) {
        $file = $req->file('image_not_selected');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image_not_selected = 'uploads/' . $fileName;
      }

      if ($model->save()) {
        return Redirect::back()->withErrors('Cập nhật thành công!')->withInput();        
      }
    }
  }

  public function delete(Request $req)
  {
      if ($req->ajax()) {
          try {
              $ids = $req->ids; // Lấy danh sách các id
              BuyTokenHeader::whereIn('id', $ids)->delete(); // Xóa các bản ghi có id trong danh sách
  
              return response(['message' => 'success']);
          } catch (\Exception $e) {
              return response(['message' => 'fail']);
          }
      }
  }
  
}
