<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Tokenmics;
use App\Game;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Admin\FunctionController;
use App\Http\Requests\EventRequest;
use DB;
use Illuminate\Support\Str;
use App\Tag;
use App\TagList;
use App\Http\Requests\TokenmicsRequest;

class TokenomicsController extends Controller
{
  public function index(Request $request)
  {
    $data = DB::select("SELECT * FROM tokenmics ORDER BY vi_tri");
    return view('admin.tokenmics.tokenmics_index', compact('data'));
  }
  public function create(Request $request)
  {
    return view('admin.tokenmics.tokenmics_create');
  }
  public function postCreate(TokenmicsRequest $req)
  {
    $model = new Tokenmics;
    $model->fill($req->all());
    // $model->slug = Str::slug($req->title, '-');

    if ($req->hasFile('image')) {
      $file = $req->file('image');
      $fileName = uniqid() . "-" . $file->getClientOriginalName();
      $file->storeAs('uploads', $fileName);
      $model->image = 'uploads/' . $fileName;
    }


    $model->save();
    return redirect()->route('tokenomics.index')->withErrors('Tạo tokenmics thành công!')->withInput();
    
  }
  public function update($id)
  {
    $model = Tokenmics::find($id);
    if (!$model) {
      return redirect()->route('tokenomics.index')->withErrors('Không tìm thấy user!');
    }
    return view('admin.tokenmics.tokenmics_update', compact('model'));
  }

  public function postUpdate(NewsUpdateRequest $req)
  {
    $model = Tokenmics::find((int)$req->id);

    if (!$model)
      return redirect()->route('tokenomics.index')->withErrors('Không tìm thấy sự kiện!');
    else {
      $model->fill($req->all());
      // $model->slug = Str::slug($req->title, '-');
      
      if ($req->hasFile('image')) {
        $file = $req->file('image');
        $fileName = uniqid() . "-" . $file->getClientOriginalName();
        $file->storeAs('uploads', $fileName);
        $model->image = 'uploads/' . $fileName;
      }
      $model->save();
      return redirect()->route('tokenomics.index')->withErrors('Upload tokenmics thành công!')->withInput();
    }
  }

  public function delete(Request $req)
  {
    if ($req->ajax()) {

      try {
        $pr = Tokenmics::find((int)$req->id);

        if ($pr->delete()) {

          return response(['message' => 'success']);
        } else {

          return response(['message' => 'fail']);
        }
      } catch (\Exception $e) {
      }
    }
  }
}
